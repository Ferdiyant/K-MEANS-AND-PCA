import streamlit as st
from sqlalchemy import create_engine, text
import pandas as pd

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def add_data():
    st.subheader("Tambah Data Anak Stunting")

    # Ambil daftar kecamatan dari database
    try:
        with engine.connect() as conn:
            kecamatan_list = pd.read_sql("SELECT DISTINCT KEC FROM stunting", conn)["KEC"].tolist()
    except:
        kecamatan_list = []

    with st.form("form_tambah_data", clear_on_submit=True):
        Nama = st.text_input("Nama Anak")
        JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"])
        KEC = st.selectbox("Kecamatan", kecamatan_list if kecamatan_list else ["Kecamatan belum tersedia"])
        U = st.number_input("Umur (bulan)", min_value=0, max_value=60)
        TB = st.number_input("Tinggi Badan (cm)", min_value=0.0, format="%.2f")
        BB = st.number_input("Berat Badan (kg)", min_value=0.0, format="%.2f")
        GI = st.selectbox("Status Gizi", ["Sedikit Terpenuhi", "Cukup Terpenuhi", "Terpenuhi"])
        PA = st.selectbox("Pola Asuhan", ["Sedang", "Baik", "Buruk"])
        PE = st.number_input("Pendapatan Ekonomi", min_value=0.0, format="%.2f")
        SA = st.selectbox("Sanitasi", ["Sedang", "Baik", "Buruk"])

        submit = st.form_submit_button("Simpan ke Database")
        	

    if submit:
        if not Nama.strip():
            st.error("Nama tidak boleh kosong.")
        elif U == 0 or TB == 0.0 or BB == 0.0:
            st.error("Umur, TB, dan BB tidak boleh 0.")
        elif not kecamatan_list or KEC not in kecamatan_list:
            st.error("Kecamatan tidak valid.")
        else:
            try:
                with engine.begin() as conn:
                    conn.execute(text("""
                        INSERT INTO stunting (Nama, JK, KEC, U, TB, BB, GI, PA, PE, SA)
                        VALUES (:Nama, :JK, :KEC, :U, :TB, :BB, :GI, :PA, :PE, :SA)
                    """), {
                        "Nama": Nama, "JK": JK, "KEC": KEC, "U": U,
                        "TB": TB, "BB": BB, "GI": GI,
                        "PA": PA, "PE": PE, "SA": SA
                    })
                st.success("Data berhasil ditambahkan!")
                st.rerun()
            except Exception as e:
                st.error(f"Gagal menyimpan data: {e}")
