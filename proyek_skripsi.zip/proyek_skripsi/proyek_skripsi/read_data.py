# read_data.py
import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from add_data import add_data
from update_data import update_data
from delete_data import delete_data

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def show_data():
    st.subheader("Data Anak Stunting")

    menu_opsi = st.radio("Pilih Aksi:", ["Lihat Data", "Tambah Data", "Update Data", "Hapus Data"], horizontal=True)

    if menu_opsi == "Lihat Data":
        df = pd.read_sql("SELECT * FROM stunting", engine)
        st.dataframe(df, use_container_width=True)

    elif menu_opsi == "Tambah Data":
        add_data()

    elif menu_opsi == "Update Data":
        update_data()

    elif menu_opsi == "Hapus Data":
        delete_data()
