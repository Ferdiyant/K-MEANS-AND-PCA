import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text

# Koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("Update Data Stunting")

    # Ambil data dari tabel 'stunting'
    df = pd.read_sql("SELECT * FROM stunting", con=engine)

    if df.empty:
        st.warning("Tidak ada data yang tersedia.")
        return

    st.subheader("Data Saat Ini")
    st.dataframe(df)

    # Dropdown untuk pilih ID
    selected_id = st.selectbox(
        "Pilih ID untuk diperbarui",
        options=df["id"],
        format_func=lambda x: f"ID {x} - {df[df['id'] == x]['Nama'].values[0]}"
    )

    # Ambil data berdasarkan ID
    selected_row = df[df["id"] == selected_id].iloc[0]

    st.subheader(f"Perbarui Data untuk ID: {selected_id}")
    with st.form("form_update"):
        # Input dengan nilai default dari database
        nama = st.text_input("Nama", value=selected_row["Nama"])
        umur = st.number_input("Umur", min_value=0, value=int(selected_row["U"]))
        tb = st.number_input("Tinggi Badan", min_value=0, value=int(selected_row["TB"]))
        bb = st.number_input("Berat Badan", min_value=0, value=int(selected_row["BB"]))
        pendapatan = st.number_input("Pendapatan Ekonomi", min_value=0, value=int(selected_row["PE"]))

        jk_options = ["Laki-laki", "Perempuan"]
        jk = st.selectbox("Jenis Kelamin", jk_options, index=jk_options.index(selected_row["JK"]))

        pa_options = ["Baik", "Sedang", "Buruk"]
        pa = st.selectbox("Pola Asuhan", pa_options, index=pa_options.index(selected_row["PA"]))

        gi_options = ["Sedikit Terpenuhi", "Cukup Terpenuhi", "Terpenuhi"]
        gi = st.selectbox("Status Gizi", gi_options, index=gi_options.index(selected_row["GI"]))

        sa_options = ["Baik", "Sedang", "Buruk"]
        sa = st.selectbox("Sanitasi", sa_options, index=sa_options.index(selected_row["SA"]))

        submitted = st.form_submit_button("Simpan Perubahan")

        if submitted:
            try:
                update_query = text("""
                    UPDATE stunting
                    SET Nama = :nama, U = :umur, TB = :tb, BB = :bb, PE = :pendapatan,
                        JK = :jk, PA = :pa, GI = :gi, SA = :sa
                    WHERE id = :id
                """)
                values = {
                    "nama": nama,
                    "umur": umur,
                    "tb": tb,
                    "bb": bb,
                    "pendapatan": pendapatan,
                    "jk": jk,
                    "pa": pa,
                    "gi": gi,
                    "sa": sa,
                    "id": selected_id
                }

                with engine.begin() as conn:
                    conn.execute(update_query, values)

                st.success("✅ Data berhasil diperbarui!")
            except Exception as e:
                st.error(f"❌ Gagal memperbarui data: {e}")
