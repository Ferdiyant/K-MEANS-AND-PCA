# app.py (main.py)
import streamlit as st
from statistik import main
from read_data import show_data

st.set_page_config(page_title="Aplikasi Data Stunting", layout="wide")

# Navigasi dengan session_state
if "menu" not in st.session_state:
    st.session_state.menu = "Lihat Data"

menu_options = ["Lihat Data", "Statistik"]

menu = st.sidebar.radio("Navigasi", menu_options, 
                        index=menu_options.index(st.session_state.menu) if st.session_state.menu in menu_options else 0)

if menu == "Lihat Data":
    show_data()
elif menu == "Statistik":
    main()
