import streamlit as st
from sqlalchemy import create_engine
import pandas as pd

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.subheader("✏️ Edit Data Anak")

    df = pd.read_sql("SELECT * FROM stunting", engine)

    selected_nama = st.selectbox("Pilih Nama Anak", df["Nama"].unique())

    selected_row = df[df["Nama"] == selected_nama].iloc[0]

    with st.form("form_edit"):
        jk = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"], index=["Laki-laki", "Perempuan"].index(selected_row["JK"]))
        kec = st.text_input("Kecamatan", selected_row["KEC"])
        umur = st.number_input("Umur (bulan)", min_value=0, value=int(selected_row["U"]))
        tb = st.number_input("Tinggi Badan (cm)", min_value=0.0, value=float(selected_row["TB"]))
        bb = st.number_input("Berat Baan (kg)", min_value=0.0, value=float(selected_row["BB"]))
        gizi = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], index=["Baik", "Buruk", "Kurang", "Lebih"].index(selected_row["GI"]))
        pend_ayah = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "Sarjana"], index=["SD", "SMP", "SMA", "Sarjana"].index(selected_row["PA"]))
        pend_ibu = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "Sarjana"], index=["SD", "SMP", "SMA", "Sarjana"].index(selected_row["PE"]))
        asupan = st.selectbox("Asupan Makanan", ["Cukup", "Kurang", "Lebih"], index=["Cukup", "Kurang", "Lebih"].index(selected_row["SA"]))

        submit = st.form_submit_button("Update")

    if submit:
        try:
            with engine.begin() as conn:
                conn.execute(
                    """
                    UPDATE stunting SET JK=%s, KEC=%s, U=%s, TB=%s, BB=%s, GI=%s, PA=%s, PE=%s, SA=%s
                    WHERE Nama=%s
                    """,
                    (jk, kec, umur, tb, bb, gizi, pend_ayah, pend_ibu, asupan, selected_nama)
                )
            st.success("✅ Data berhasil diperbarui.")
        except Exception as e:
            st.error(f"Gagal update data: {e}")