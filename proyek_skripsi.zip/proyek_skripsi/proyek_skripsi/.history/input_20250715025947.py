import streamlit as st
from sqlalchemy import create_engine, text

# Koneksi ke database MySQL
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def run():
    st.title("📥 Input Data Stunting")

    with st.form("form_input"):
        Nama = st.text_input("Nama Anak", key="nama")
        JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"], key="jk")
        KEC = st.selectbox("Kecamatan", ["Paiton", "Kraksaan", "Gending", "Dringu", "Lainnya"], key="kec")
        U = st.number_input("Umur (bulan)", min_value=0, max_value=60, key="u")
        TB = st.number_input("Tinggi Badan (cm)", min_value=0.0, key="tb")
        BB = st.number_input("Berat Badan (kg)", min_value=0.0, key="bb")
        GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], key="gi")
        PA = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "S1", "Lainnya"], key="pa")
        PE = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "S1", "Lainnya"], key="pe")
        SA = st.selectbox("Status Asupan Makanan", ["Cukup", "Kurang", "Lebih"], key="sa")
        
        submitted = st.form_submit_button("Simpan ke Database")

    if submitted:
        try:
            query = text("""
                INSERT INTO stunting 
                (Nama, JK, KEC, U, TB, BB, GI, PA, PE, SA)
                VALUES (:Nama, :JK, :KEC, :U, :TB, :BB, :GI, :PA, :PE, :SA)
            """)
            with engine.begin() as conn:
                conn.execute(query, {
                    "Nama": Nama,
                    "JK": JK,
                    "KEC": KEC,
                    "U": U,
                    "TB": TB,
                    "BB": BB,
                    "GI": GI,
                    "PA": PA,
                    "PE": PE,
                    "SA": SA
                })
            st.success("✅ Data berhasil disimpan ke database!")

            # 🔁 Reset form input
            st.session_state["Nama"] = ""
            st.session_state["JK"] = "Laki-laki"
            st.session_state["KEC"] = "Paiton"
            st.session_state["U"] = 0
            st.session_state["TB"] = 0.0
            st.session_state["BB"] = 0.0
            st.session_state["GI"] = "Baik"
            st.session_state["PA"] = "SD"
            st.session_state["PE"] = "SD"
            st.session_state["SA"] = "Cukup"


        except Exception as e:
            st.error(f"❌ Gagal menyimpan data: {e}")
