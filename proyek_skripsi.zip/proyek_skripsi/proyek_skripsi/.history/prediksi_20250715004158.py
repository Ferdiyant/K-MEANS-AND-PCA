import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def run():
    st.title("🤖 Prediksi Status Gizi")

    try:
        df = pd.read_sql("SELECT * FROM stunting", engine)

        if len(df) < 5:
            st.warning("Masukkan minimal 5 data untuk prediksi.")
            return

        st.write("📊 Data dari Database:")
        st.dataframe(df)

        # Label dummy (berat < 10 = Gizi Buruk)
        df['label'] = (df['berat'] < 10).astype(int)

        X = df[['umur', 'tinggi', 'berat']]
        y = df['label']

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = LogisticRegression()
        model.fit(X_train, y_train)

        st.subheader("💡 Masukkan Data Baru untuk Prediksi")
        umur_pred = st.number_input("Umur Anak (bulan)", min_value=0, max_value=60, key="pred_umur")
        tinggi_pred = st.number_input("Tinggi Badan (cm)", key="pred_tinggi")
        berat_pred = st.number_input("Berat Badan (kg)", key="pred_berat")

        if st.button("Prediksi"):
            input_pred = [[umur_pred, tinggi_pred, berat_pred]]
            pred = model.predict(input_pred)[0]
            hasil = "Gizi Buruk" if pred == 1 else "Gizi Baik"
            st.success(f"Hasil Prediksi: **{hasil}**")

    except Exception as e:
        st.error(f"❌ Gagal memuat data: {e}")
