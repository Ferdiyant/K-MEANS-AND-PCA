import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import pymysql

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def delete_data():
    st.subheader("Hapus Data Stunting")

    df = pd.read_sql("SELECT * FROM stunting", engine)

    selected_index = st.selectbox("Pilih ID untuk dihapus", df.index, format_func=lambda x: f"ID {df['id'][x]} - {df['Nama'][x]}")

    selected_row = df.loc[selected_index]

    st.write("Data yang akan dihapus:")
    st.write(selected_row)

    if st.button("Hapus Data"):
        try:
            conn = engine.raw_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM stunting WHERE id = %s", (selected_row["id"],))
            conn.commit()
            cursor.close()
            conn.close()
            st.success("Data berhasil dihapus.")
            st.rerun()

        except Exception as e:
            st.error(f"Gagal menghapus data: {e}")