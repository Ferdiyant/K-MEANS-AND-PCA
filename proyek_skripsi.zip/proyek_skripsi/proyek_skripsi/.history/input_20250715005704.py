import streamlit as st
from sqlalchemy import create_engine, text

# Koneksi ke database MySQL
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def run():
    st.title("📥 Input Data Stunting")

    with st.form("form_input"):
        nama = st.text_input("Nama Anak")
        jk = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"])
        kec = st.selectbox("Kecamatan", ["Paiton", "Kraksaan", "Gending", "Dringu", "Lainnya"])
        umur = st.number_input("Umur (bulan)", min_value=0, max_value=60)
        tb = st.number_input("Tinggi Badan (cm)", min_value=0.0)
        bb = st.number_input("Berat Badan (kg)", min_value=0.0)
        gi = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"])
        pa = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "S1", "Lainnya"])
        pe = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "S1", "Lainnya"])
        sa = st.selectbox("Status Asupan Makanan", ["Cukup", "Kurang", "Lebih"])
        
        submitted = st.form_submit_button("Simpan ke Database")

    if submitted:
        try:
            # Gunakan text() dan placeholder SQLAlchemy (bukan %s)
            query = text("""
                INSERT INTO stunting 
                (nama, jk, kec, umur, tb, bb, gi, pa, pe, sa)
                VALUES (:nama, :jk, :kec, :umur, :tb, :bb, :gi, :pa, :pe, :sa)
            """)
            with engine.begin() as conn:
                conn.execute(query, {
                    "nama": nama,
                    "jk": jk,
                    "kec": kec,
                    "umur": umur,
                    "tb": tb,
                    "bb": bb,
                    "gi": gi,
                    "pa": pa,
                    "pe": pe,
                    "sa": sa
                })
            st.success("✅ Data berhasil disimpan ke database!")
        except Exception as e:
            st.error(f"❌ Gagal menyimpan data: {e}")
