import streamlit as st
import pandas as pd
from sqlalchemy import create_engine, text

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("🔁 Update Data Stunting")

    # Ambil data dari database
    query = "SELECT * FROM stunting"
    df = pd.read_sql(query, engine)

    # Tampilkan data untuk dipilih baris yang akan diupdate
    selected_id = st.selectbox("Pilih ID yang akan diupdate:", df["id"].tolist())

    # Ambil data baris terpilih
    selected_row = df[df["id"] == selected_id].iloc[0]

    with st.form("form_update"):
        nama = st.text_input("Nama", value=selected_row.get("Nama", ""))
        jk_options = ["Laki-laki", "Perempuan"]
        JK = st.selectbox("Jenis Kelamin", jk_options, index=jk_options.index(selected_row.get("JK", jk_options[0])))

        umur = st.number_input("Umur", min_value=0, value=int(selected_row.get("Umur", 0)))
        BB = st.number_input("Berat Badan (kg)", value=float(selected_row.get("BB", 0)))
        TB = st.number_input("Tinggi Badan (cm)", value=float(selected_row.get("TB", 0)))

        pend_ibu_options = ["SD", "SMP", "SMA", "Sarjana"]
        PE = st.selectbox("Pendidikan Ibu", pend_ibu_options, index=pend_ibu_options.index(selected_row.get("PE", "SD")))

        SA = st.selectbox("Asupan Makanan", ["Cukup", "Kurang", "Lebih"], index=["Cukup", "Kurang", "Lebih"].index(selected_row.get("SA", "Cukup")))
        GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], index=["Baik", "Buruk", "Kurang", "Lebih"].index(selected_row.get("GI", "Baik")))

        submit = st.form_submit_button("Update Data")

    if submit:
        try:
            update_query = text("""
                UPDATE data_stunting
                SET Nama=:nama, JK=:jk, Umur=:umur, BB=:bb, TB=:tb, PE=:pe, SA=:sa, GI=:gi
                WHERE id=:id
            """)
            with engine.connect() as conn:
                conn.execute(update_query, {
                    "nama": nama,
                    "jk": JK,
                    "umur": umur,
                    "bb": BB,
                    "tb": TB,
                    "pe": PE,
                    "sa": SA,
                    "gi": GI,
                    "id": selected_id
                })
                conn.commit()

            st.success("✅ Data berhasil diperbarui!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Gagal memperbarui data: {e}")
