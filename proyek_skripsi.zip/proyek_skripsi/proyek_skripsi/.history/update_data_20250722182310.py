import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import pymysql

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.subheader("✏️ Update Data Stunting")

    df = pd.read_sql("SELECT * FROM stunting", engine)

    if df.empty:
        st.warning("❗ Tidak ada data untuk diperbarui.")
        return

    selected_index = st.selectbox("Pilih ID untuk diupdate", df.index, format_func=lambda x: f"{df['id'][x]} - {df['Nama'][x]}")
    selected_row = df.loc[selected_index]

    st.write("**Data saat ini:**")
    st.write(selected_row)

    with st.form("update_form"):
        nama = st.text_input("Nama", selected_row["Nama"])
        umur = st.number_input("Umur", min_value=0, value=int(selected_row["Umur"])) if "Umur" in selected_row else st.number_input("Umur", min_value=0)
        JK = st.selectbox("Jenis Kelamin", ["L", "P"], index=["L", "P"].index(selected_row["JK"]))
        GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], index=["Baik", "Buruk", "Kurang", "Lebih"].index(selected_row["GI"]))
        PA = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "Sarjana"], index=["SD", "SMP", "SMA", "Sarjana"].index(selected_row["PA"]))
        PE = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "Sarjana"], index=["SD", "SMP", "SMA", "Sarjana"].index(selected_row["PE"]))
        SA = st.selectbox("Asupan Makanan", ["Cukup", "Kurang", "Lebih"], index=["Cukup", "Kurang", "Lebih"].index(selected_row["SA"]))

        submitted = st.form_submit_button("🔄 Update")

        if submitted:
            try:
                conn = engine.raw_connection()
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE stunting 
                    SET Nama = %s, Umur = %s, JK = %s, GI = %s, PA = %s, PE = %s, SA = %s
                    WHERE id = %s
                """, (nama, umur, JK, GI, PA, PE, SA, selected_row["id"]))
                conn.commit()
                cursor.close()
                conn.close()
                st.success("✅ Data berhasil diperbarui.")
                st.rerun()

            except Exception as e:
                st.error(f"❌ Gagal memperbarui data: {e}")
