import streamlit as st
import input
import prediksi

# Sidebar navigasi
st.sidebar.title("Klasterisasi Stunting Bondowoso")
halaman = st.sidebar.radio("Pilih Halaman:", ["Input Data", "Prediksi"])

# Routing ke halaman sesuai pilihan
if halaman == "Input Data":
    input.run()
elif page == "Prediksi":
    prediksi.run()



