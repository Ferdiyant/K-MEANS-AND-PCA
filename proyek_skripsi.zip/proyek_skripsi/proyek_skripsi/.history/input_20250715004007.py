import streamlit as st
from sqlalchemy import create_engine

# Koneksi ke MySQL
engine = create_engine("mysql+pymysql://root:@localhost/mydb")


def run():
    st.title("📥 Input Data Stunting")

    with st.form("form_input"):
        nama = st.text_input("Nama Anak")
        umur = st.number_input("Umur (bulan)", min_value=0, max_value=60)
        tinggi = st.number_input("Tinggi Badan (cm)")
        berat = st.number_input("Berat Badan (kg)")
        submitted = st.form_submit_button("Simpan ke Database")

    if submitted:
        try:
            query = "INSERT INTO stunting (nama, umur, tinggi, berat) VALUES (%s, %s, %s, %s)"
            with engine.begin() as conn:
                conn.execute(query, (nama, umur, tinggi, berat))
            st.success("✅ Data berhasil disimpan!")
        except Exception as e:
            st.error(f"❌ Gagal menyimpan data: {e}")
