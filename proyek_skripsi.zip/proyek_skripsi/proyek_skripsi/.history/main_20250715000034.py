#from sqlalchemy import create_engine
#import pandas as pd
import streamlit as st

# Ganti sesuai konfigurasi MySQL kamu
#engine = create_engine("mysql+pymysql://root:@localhost/mydb")

conn = st. connection('mysql', type='sql')
df = conn.query('SELECT * from ')

# Query
query = "SELECT * FROM stunting"
df = pd.read_sql(query, engine)

st.dataframe(df)
