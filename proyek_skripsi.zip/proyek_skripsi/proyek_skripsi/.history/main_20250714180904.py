import streamlit as st
import pandas as pd

# Membuat koneksi ke database MySQL
conn = st.connection("mysql", type="sql")

st.title("Tampilan Data dari MySQL")

# Contoh query ke tabel
query = "SELECT * FROM nama_tabel LIMIT 100"

# Eksekusi dan tampilkan data
df = conn.query(query, ttl=600)  # cache selama 600 detik
st.dataframe(df)
import streamlit as st
import pandas as pd

# Membuat koneksi ke database MySQL
conn = st.connection("mysql", type="sql")

st.title("Tampilan Data dari MySQL")

# Contoh query ke tabel
query = "SELECT * FROM nama_tabel LIMIT 100"

# Eksekusi dan tampilkan data
df = conn.query(query, ttl=600)  # cache selama 600 detik
st.dataframe(df)
