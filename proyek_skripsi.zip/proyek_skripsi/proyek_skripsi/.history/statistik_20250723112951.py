# app.py (continued)
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score, adjusted_rand_score, normalized_mutual_info_score
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import train_test_split
from sklearn.metrics.pairwise import euclidean_distances
import mysql.connector
from mysql.connector import Error

def load_data(uploaded_file):
    """Loads data from an uploaded Excel file."""
    if uploaded_file is not None:
        data = pd.read_excel('stunting.xlsx')
        df = pd.DataFrame(data)
        return df
    return None

def preprocess_data(df):
    """Preprocesses the raw DataFrame."""
    if df is not None:
        # Keep original data for display and merging later
        df_processed = df.copy()

        # Drop columns
        df_processed = df_processed.drop(['KEC', 'Nama'], axis=1, errors='ignore')

        # Convert categorical features to numerical
        df_processed['jenis kelamin'] = df_processed['JK'].str.lower().map({'laki-laki': 0, 'perempuan': 1})
        df_processed['pola asuhan'] = df_processed['PA'].str.lower().map({'baik': 2, 'sedang': 1, 'buruk': 0})
        df_processed['gizi ibu'] = df_processed['GI'].str.lower().map({'terpenuhi': 2, 'cukup terpenuhi': 1, 'sedikit terpenuhi': 0})
        df_processed['sanitasi'] = df_processed['SA'].str.lower().map({'baik': 2, 'sedang': 1, 'buruk': 0})

        # Select only numerical columns for PCA and KMeans
        data_numerik = df_processed.select_dtypes(include=[np.number])

        return data_numerik # Return processed df too
    return None, None

def perform_pca(data_numerik, n_components):
    """Performs PCA on the numerical data."""
    if data_numerik is not None and n_components is not None:
        scaler = StandardScaler()
        x_scaled = scaler.fit_transform(data_numerik)
        pca = PCA(n_components=n_components)
        x_pca = pca.fit_transform(x_scaled)
        return x_pca, pca, scaler # Return the fitted scaler
    return None, None, None

def perform_kmeans(x_pca, n_clusters):
    """Performs KMeans clustering on the PCA-transformed data."""
    if x_pca is not None and n_clusters is not None:
        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10) # Added n_init for newer sklearn versions
        clusters = kmeans.fit_predict(x_pca)
        return clusters, kmeans
    return None, None

def plot_correlation_heatmap(df_numerik):
    """Plots the correlation heatmap of numerical features."""
    if df_numerik is not None:
        plt.figure(figsize=[12, 8])
        plt.title("Correlation Graph", fontsize=14)
        matrix = np.triu(df_numerik.corr())
        sns.heatmap(df_numerik.corr(), annot=True, cmap='coolwarm', mask=matrix, cbar=False)
        return plt.gcf()
    return None

def plot_explained_variance(pca):
    """Plots the explained variance ratio by number of components."""
    if pca is not None:
        explained_variance_ratios = np.cumsum(pca.explained_variance_ratio_)
        plt.figure(figsize=(8, 5))
        plt.plot(range(1, len(explained_variance_ratios) + 1), explained_variance_ratios, marker='o')
        plt.xlabel('Number of Components')
        plt.ylabel('Cumulative Explained Variance')
        plt.title('Cumulative Explained Variance by Number of Components')
        plt.grid(True)
        return plt.gcf()
    return None

def plot_clustering_2d(x_pca, clusters, centroids=None):
    """Plots the 2D clustering results."""
    if x_pca is not None and clusters is not None:
        plt.figure(figsize=(10, 6))
        plt.scatter(x_pca[:, 0], x_pca[:, 1], c=clusters, cmap='viridis', alpha=0.6)
        if centroids is not None:
            plt.scatter(centroids[:, 0], centroids[:, 1], c='red', s=200, marker='X', label='Centroids')
        plt.title('2D Clustering Visualization (PC1 vs PC2)')
        plt.xlabel('PC1')
        plt.ylabel('PC2')
        plt.legend()
        plt.grid(True)
        return plt.gcf()
    return None

def plot_clustering_3d(x_pca, clusters):
    """Plots the 3D clustering results."""
    if x_pca is not None and clusters is not None and x_pca.shape[1] >= 3:
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(x_pca[:, 0], x_pca[:, 1], x_pca[:, 2], c=clusters, cmap='viridis')
        ax.set_xlabel('PC1')
        ax.set_ylabel('PC2')
        ax.set_zlabel('PC3')
        plt.title('3D Clustering Visualization')
        return fig
    elif x_pca is not None and x_pca.shape[1] < 3:
        st.warning("Cannot plot in 3D with less than 3 PCA components.")
    return None


def plot_loadings(pca, feature_names):
    """Plots the PCA loadings."""
    if pca is not None and feature_names is not None:
        loadings = pca.components_.T * np.sqrt(pca.explained_variance_)
        loadings_df = pd.DataFrame(loadings, columns=[f'PC{i}' for i in range(1, pca.n_components_ + 1)], index=feature_names)
        plt.figure(figsize=(10, 6))
        sns.heatmap(loadings_df, annot=True, cmap='coolwarm')
        plt.title('Loadings Plot')
        plt.xlabel('Component')
        plt.ylabel('Feature')
        return plt.gcf()
    return None

def plot_elbow_method(x_pca):
    """Plots the Elbow Method for KMeans."""
    if x_pca is not None:
        inertia = []
        K = range(2, 11)
        for k in K:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            kmeans.fit(x_pca)
            inertia.append(kmeans.inertia_)
        plt.figure(figsize=(10, 6))
        plt.plot(K, inertia, marker='o')
        plt.xlabel('Number of Clusters (K)')
        plt.ylabel('Inertia')
        plt.title('Elbow Method for Determining Number of Clusters')
        plt.grid(True)
        
    return None

def plot_davies_bouldin(x_pca):
    """Plots the Davies-Bouldin scores for KMeans."""
    if x_pca is not None:
        davies_bouldin_scores_list = []
        K = range(2, 11)
        for k in K:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(x_pca)
            score = davies_bouldin_score(x_pca, labels)
            davies_bouldin_scores_list.append(score)
        plt.figure(figsize=(10, 6))
        plt.plot(K, davies_bouldin_scores_list, marker='o', color='red')
        plt.xlabel('Number of Clusters (K)')
        plt.ylabel('Davies-Bouldin Index')
        plt.title('Davies-Bouldin Index for Determining Number o-f Clusters')
        plt.grid(True)
        
    return None

def plot_silhouette_score(x_pca):
    """Plots the Silhouette scores for KMeans."""
    if x_pca is not None:
        silhouette_scores = []
        K = range(2, 11)
        for k in K:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels = kmeans.fit_predict(x_pca)
            score = silhouette_score(x_pca, labels)
            silhouette_scores.append(score)
        plt.figure(figsize=(10, 6))
        plt.plot(K, silhouette_scores, marker='x', color='green')
        plt.title('Silhouette Score for Determining Number of Clusters')
        plt.xlabel('Number of Clusters')
        plt.ylabel('Silhouette Score')
        plt.grid(True)
        
    return None

def plot_cluster_distribution(confusion_matrix, title):
    """Plots the distribution of original categories within clusters."""
    if confusion_matrix is not None:
        ax = confusion_matrix.plot(kind='bar', figsize=(10, 6), colormap='tab10')
        plt.title(title)
        plt.xlabel('Cluster')
        plt.ylabel('Count')
        plt.xticks(rotation=0)
        plt.legend(title='Original Category')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        return plt.gcf()
    return None


def generate_cluster_summary(original_df, x_pca, clusters):
    """Generates a summary of clusters based on original features."""
    if original_df is not None and x_pca is not None and clusters is not None:
        # Ensure the original_df has the same index as the clusters for correct merging
        df_with_clusters = original_df.copy()
        df_with_clusters['Cluster'] = clusters # Assuming clusters align with original_df rows

        cluster_summary = df_with_clusters.groupby('Cluster').mean(numeric_only=True)
        return cluster_summary
    return None

def generate_confusion_matrices(original_df, clusters):
    """Generates confusion matrices for categorical features vs clusters."""
    if original_df is not None and clusters is not None:
        # Ensure the original_df has the same index as the clusters
        original_df_indexed = original_df.copy()
        original_df_indexed['Cluster'] = clusters # Assuming clusters align with original_df rows

        # Check if categorical columns exist before attempting to map
        confusion_sex = None
        if 'jenis kelamin' in original_df_indexed.columns:
             confusion_sex = pd.crosstab(original_df_indexed['Cluster'], original_df_indexed['jenis kelamin'].map({0: 'Laki-laki', 1: 'Perempuan'}), rownames=['Cluster'], colnames=['Jenis Kelamin'])

        confusion_gizi = None
        if 'gizi ibu' in original_df_indexed.columns:
             label_map = {0: 'Rendah', 1: 'Sedang', 2: 'Tinggi'}
             confusion_gizi = pd.crosstab(original_df_indexed['Cluster'], original_df_indexed['gizi ibu'].map(label_map), rownames=['Cluster'], colnames=['Gizi Ibu'])

        confusion_asuhan = None
        if 'pola asuhan' in original_df_indexed.columns:
             label_map = {0: 'Buruk', 1: 'Sedang', 2: 'Baik'} # Corrected map based on preprocessing
             confusion_asuhan = pd.crosstab(original_df_indexed['Cluster'], original_df_indexed['pola asuhan'].map(label_map), rownames=['Cluster'], colnames=['Pola Asuhan'])

        confusion_sanitasi = None
        if 'sanitasi' in original_df_indexed.columns:
             label_map = {0: 'Buruk', 1: 'Sedang', 2: 'Baik'} # Corrected map based on preprocessing
             confusion_sanitasi = pd.crosstab(original_df_indexed['Cluster'], original_df_indexed['sanitasi'].map(label_map), rownames=['Cluster'], colnames=['Sanitasi'])


        return confusion_sex, confusion_gizi, confusion_asuhan, confusion_sanitasi
    return None, None, None, None

def create_db_connection(host_name, database_name, user_name, user_password):
    """Create a database connection to the MySQL database."""
    connection = None
    try:
        connection = mysql.connector.connect(
            host=host_name,
            database=database_name,
            user=user_name,
            password=user_password
        )
        st.success("MySQL Database connection successful!")
        return connection
    except Error as e:
        st.error(f"Error connecting to MySQL Database: '{e}'")
    return None

def predict_new_data(new_data, scaler, pca, kmeans):
    """Preprocesses new data and predicts its cluster."""
    if new_data is not None and scaler is not None and pca is not None and kmeans is not None:
        # Preprocess new data (similar to preprocess_data but for a single row or multiple rows)
        processed_new_data = new_data.copy()

        # Map categorical features to numerical
        # Handle potential missing columns in new_data if it's from database or manual input
        categorical_maps = {
            'jenis kelamin': {'laki-laki': 0, 'perempuan': 1},
            'pola asuhan': {'baik': 2, 'sedang': 1, 'buruk': 0},
            'gizi ibu': {'terpenuhi': 2, 'cukup terpenuhi': 1, 'sedikit terpenuhi': 0},
            'sanitasi': {'baik': 2, 'sedang': 1, 'buruk': 0}
        }

        for col, mapping in categorical_maps.items():
            if col in processed_new_data.columns:
                processed_new_data[col] = processed_new_data[col].astype(str).str.lower().map(mapping)
            else:
                processed_new_data[col] = np.nan # Or some default value


        # Select only numerical columns in the correct order as training data
        numerical_cols_order = ['jenis kelamin', 'umur', 'tinggi badan', 'berat badan', 'gizi ibu', 'pola asuhan', 'pendapatan ekonomi', 'sanitasi'] # Ensure this matches the order in preprocess_data
        # Ensure all columns in numerical_cols_order exist in processed_new_data before selecting
        for col in numerical_cols_order:
            if col not in processed_new_data.columns:
                processed_new_data[col] = np.nan # Add missing column with NaN

        new_data_numerik = processed_new_data[numerical_cols_order].dropna() # Drop rows with NaN in numerical features for prediction


        if new_data_numerik.empty:
            st.warning("New data is empty or contains only missing values after selecting numerical columns.")
            return None

        # Scale the new data using the *fitted* scaler from training data
        scaled_new_data = scaler.transform(new_data_numerik)

        # Transform the scaled new data using the *fitted* PCA model
        pca_new_data = pca.transform(scaled_new_data)

        # Predict the cluster using the *fitted* KMeans model
        predicted_clusters = kmeans.predict(pca_new_data)

        return predicted_clusters # Return the predicted cluster labels (can be multiple for database loading)
    return None


def main():
    st.title("PCA and KMeans Clustering Application")

    st.markdown("""
    This application performs Principal Component Analysis (PCA) and KMeans clustering on your uploaded data.
    PCA is used to reduce the dimensionality of the data while retaining as much of the original variance as possible.
    KMeans clustering is an unsupervised learning algorithm that partitions the data into K distinct groups (clusters).
    You can upload your data, adjust the parameters for PCA and KMeans, and visualize the results.
    """)

    st.sidebar.header("Upload Data")
    uploaded_file = st.sidebar
    #.file_uploader("Upload your Excel file", type=["xlsx"])

    df = load_data(uploaded_file)

    if df is not None:
        #st.success("File uploaded and data loaded successfully!")

        st.header("Data Overview")
        st.markdown("""
        Here's a preview of the original data, along with summary statistics, information on missing values,
        and the count of duplicated rows. Understanding your data is the first step in any analysis.
        """)
        st.write("Original Data Preview:")
        st.dataframe(df.head())
        st.write("Original Data Description:")
        st.dataframe(df.describe())
        st.write("Missing Values:")
        st.write(df.isnull().sum())
        st.write(f"Number of duplicated rows: {df.duplicated().sum()}")

        st.header("Preprocessing")
        st.markdown("""
        In this step, the data is prepared for PCA and KMeans. This involves:
        - Dropping columns that are not needed for the analysis ('Kecamatan', 'Nama').
        - Converting categorical features ('jenis kelamin', 'pola asuhan', 'gizi ibu', 'sanitasi') into numerical representations.
        - Selecting only the numerical columns for the analysis.
        """)
        data_numerik, df_processed = preprocess_data(df) # Get the processed df here

        if data_numerik is not None and df_processed is not None:
            st.success("Data preprocessing completed!")
            st.write("Preprocessed Data Preview (Numerical Features):")
            st.dataframe(data_numerik.head())

            # Correlation Heatmap
            st.header("Correlation Heatmap")
            st.markdown("""
            This heatmap shows the pairwise correlation between the numerical features in your preprocessed data.
            Values close to 1 or -1 indicate strong positive or negative linear relationships, respectively.
            Values close to 0 indicate weak linear relationships.
            """)
            corr_fig = plot_correlation_heatmap(data_numerik)
            if corr_fig:
                st.pyplot(corr_fig)
                plt.close(corr_fig)

            # PCA Parameters
            st.sidebar.header("PCA Parameters")
            max_pca_components = min(data_numerik.shape[1], data_numerik.shape[0]) # Ensure n_components is not more than min(n_samples, n_features)
            if max_pca_components < 1:
                 st.sidebar.warning("Not enough features or samples for PCA.")
                 n_components = 0
            else:
                n_components = st.sidebar.slider(
                    "Number of PCA components",
                    1,
                    max_pca_components,
                    min(2, max_pca_components) # Default to 2 or max_pca_components if less than 2
                )


            if n_components > 0:
                x_pca, pca, scaler = perform_pca(data_numerik, n_components) # Get the fitted scaler here

                if x_pca is not None and pca is not None and scaler is not None:
                    st.header("PCA Results")
                    st.markdown(f"""
                    PCA has been performed with {n_components} components.
                    These components are linear combinations of the original features and are ordered by the amount of variance they explain.
                    """)
                    st.write(f"Explained variance ratio with {n_components} components: {np.sum(pca.explained_variance_ratio_):.4f}")

                    st.subheader("Explained Variance Plot")
                    st.markdown("""
                    This plot shows the cumulative explained variance as the number of components increases.
                    It helps you decide how many components to keep to retain a desired percentage of the total variance.
                    """)
                    explained_variance_fig = plot_explained_variance(pca)
                    if explained_variance_fig:
                        st.pyplot(explained_variance_fig)
                        plt.close(explained_variance_fig) # Close the figure to prevent display issues

                    st.subheader("Loadings Plot")
                    st.markdown("""
                    The loadings plot shows how much each original feature contributes to each principal component.
                    Features with higher absolute loading values have a stronger influence on the component.
                    """)
                    loadings_fig = plot_loadings(pca, data_numerik.columns)
                    if loadings_fig:
                        st.pyplot(loadings_fig)
                        plt.close(loadings_fig)


                    # KMeans Parameters
                    st.sidebar.header("KMeans Parameters")
                    st.sidebar.markdown("""
                    Select the number of clusters (K) for the KMeans algorithm. KMeans aims to partition
                    data points into K clusters such that each point belongs to the cluster with the nearest mean (centroid).
                    """)
                    # Set a reasonable max for clusters, e.g., up to sqrt(n_samples) or 10
                    max_clusters = min(10, x_pca.shape[0] // 2) # Max clusters should be less than half the number of samples
                    if max_clusters < 2:
                         st.sidebar.warning("Not enough data points for clustering with k >= 2.")
                         n_clusters = 0
                    else:
                        n_clusters = st.sidebar.slider(
                            "Number of Clusters",
                            2,
                            max_clusters,
                            min(3, max_clusters) # Default to 3 or max_clusters if less than 3
                        )


                    if n_clusters >= 2:
                        clusters, kmeans = perform_kmeans(x_pca, n_clusters)

                        if clusters is not None and kmeans is not None:
                            st.header("KMeans Clustering Results")
                            st.markdown(f"""
                            KMeans clustering has been applied with K = {n_clusters}.
                            The data points have been grouped into {n_clusters} clusters based on their similarity in the PCA space.
                            """)

                            st.subheader("Clustering Visualization")
                            st.markdown("""
                            These plots visualize the clusters in the reduced PCA space.
                            - The 2D plot shows the clusters based on the first two principal components.
                            - The 3D plot shows the clusters based on the first three principal components (if available).
                            The 'X' markers represent the centroids (mean points) of each cluster.
                            """)
                            # Plot 2D clustering if at least 2 components are selected
                            if n_components >= 2:
                                clustering_2d_fig = plot_clustering_2d(x_pca[:, :2], clusters, kmeans.cluster_centers_[:, :2])
                                if clustering_2d_fig:
                                    st.pyplot(clustering_2d_fig)
                                    plt.close(clustering_2d_fig)

                            # Plot 3D clustering if at least 3 components are selected
                            if n_components >= 3:
                                clustering_3d_fig = plot_clustering_3d(x_pca[:, :3], clusters)
                                if clustering_3d_fig:
                                    st.pyplot(clustering_3d_fig)
                                    plt.close(clustering_3d_fig)


                            st.subheader("Clustering Metrics")
                            st.markdown("""
                            Clustering metrics provide a quantitative evaluation of the clustering results.
                            - **Silhouette Score:** Measures how similar a data point is to its own cluster compared to other clusters.
                              Scores range from -1 to 1, where a higher score indicates better-defined clusters.
                            - **Davies-Bouldin Score:** Measures the average similarity ratio of each cluster with its most similar cluster.
                              A lower score indicates better clustering.
                            """)
                            try:
                                sil_score = silhouette_score(x_pca, clusters)
                                db_score = davies_bouldin_score(x_pca, clusters)
                                st.write(f"Silhouette Score: {sil_score:.4f}")
                                st.write(f"Davies-Bouldin Score: {db_score:.4f}")
                            except Exception as e:
                                st.warning(f"Could not calculate clustering metrics: {e}")


                            st.subheader("Cluster Summary")
                            st.markdown("""
                            This table shows the average values of the original numerical features for each cluster.
                            This helps in understanding the characteristics of each identified group.
                            """)
                            cluster_summary = generate_cluster_summary(df_processed, x_pca, clusters) # Use df_processed here
                            if cluster_summary is not None:
                                st.dataframe(cluster_summary)

                            st.subheader("Cluster Distribution by Original Categories")
                            st.markdown("""
                            These bar plots show the distribution of original categorical features ('Jenis Kelamin', 'Gizi Ibu', 'Pola Asuhan', 'Sanitasi')
                            within each identified cluster. This helps in understanding if the clusters correspond to specific categories.
                            """)
                            confusion_sex, confusion_gizi, confusion_asuhan, confusion_sanitasi = generate_confusion_matrices(df_processed, clusters) # Use df_processed here

                            if confusion_sex is not None:
                                sex_dist_fig = plot_cluster_distribution(confusion_sex, 'Cluster Distribution by Jenis Kelamin')
                                if sex_dist_fig:
                                     st.pyplot(sex_dist_fig)
                                     plt.close(sex_dist_fig)

                            if confusion_gizi is not None:
                                gizi_dist_fig = plot_cluster_distribution(confusion_gizi, 'Cluster Distribution by Gizi Ibu')
                                if gizi_dist_fig:
                                    st.pyplot(gizi_dist_fig)
                                    plt.close(gizi_dist_fig)

                            if confusion_asuhan is not None:
                                asuhan_dist_fig = plot_cluster_distribution(confusion_asuhan, 'Cluster Distribution by Pola Asuhan')
                                if asuhan_dist_fig:
                                    st.pyplot(asuhan_dist_fig)
                                    plt.close(asuhan_dist_fig)


                            if confusion_sanitasi is not None:
                                sanitasi_dist_fig = plot_cluster_distribution(confusion_sanitasi, 'Cluster Distribution by Sanitasi')
                                if sanitasi_dist_fig:
                                    st.pyplot(sanitasi_dist_fig)
                                    plt.close(sanitasi_dist_fig)

                            # Optional: Plot Elbow, Davies-Bouldin, Silhouette for different Ks
                            st.subheader("KMeans Evaluation Plots (for K=2 to 10)")
                            st.markdown("""
                            These plots help in choosing an optimal number of clusters (K) by evaluating clustering
                            performance for different values of K.
                            - **Elbow Method (Inertia):** Looks for an 'elbow' point where the rate of decrease in inertia slows down significantly.
                            - **Davies-Bouldin Index:** Lower values indicate better clustering. You look for the lowest point on the plot.
                            - **Silhouette Score:** Higher values indicate better clustering. You look for the highest point on the plot.
                            """)
                            elbow_fig = plot_elbow_method(x_pca)
                            if elbow_fig:
                                st.pyplot(elbow_fig)
                                plt.close(elbow_fig)

                            davies_bouldin_fig = plot_davies_bouldin(x_pca)
                            if davies_bouldin_fig:
                                st.pyplot(davies_bouldin_fig)
                                plt.close(davies_bouldin_fig)

                            silhouette_fig = plot_silhouette_score(x_pca)
                            if silhouette_fig:
                                st.pyplot(silhouette_fig)
                                plt.close(silhouette_fig)

                            # Add download button
                            st.header("Download Results")
                            st.markdown("Download the original data with the assigned cluster labels.")

                            # Create a DataFrame with original data and cluster labels
                            df_clustered = df.copy()
                            df_clustered['Cluster'] = clusters # Assuming clusters align with original df rows

                            # Convert DataFrame to CSV string
                            csv_data = df_clustered.to_csv(index=False).encode('utf-8')

                            st.download_button(
                                label="Download Clustered Data as CSV",
                                data=csv_data,
                                file_name="clustered_data.csv",
                                mime="text/csv"
                            )

                            # New Data Prediction Section
                            st.header("Predict Cluster for New Data")
                            st.markdown("Choose whether to input new data manually or load it from a database.")

                            prediction_method = st.radio(
                                "Select Prediction Data Source",
                                ('Manual Input', 'Load from Database')
                            )

                            if prediction_method == 'Manual Input':
                                st.markdown("Enter the values for a new data point to predict its cluster.")

                                # Create input widgets for each feature
                                new_data_input = {}
                                # Assuming 'Nama' and 'Kecamatan' are dropped,
                                # and other categorical features are mapped to numerical
                                # Need to get the original column names and their types
                                original_columns = df.columns.tolist()
                                columns_to_drop = ['Nama', 'Kecamatan']
                                categorical_cols = ['jenis kelamin', 'pola asuhan', 'gizi ibu', 'sanitasi']
                                numerical_cols = [col for col in original_columns if col not in columns_to_drop + categorical_cols]

                                # Input for numerical features
                                for col in numerical_cols:
                                    new_data_input[col] = st.number_input(f"Enter value for {col}", value=float(df[col].mean()))

                                # Input for categorical features
                                # Need to map the options back to original string values for selectbox
                                gender_options = ['Laki-laki', 'Perempuan']
                                gizi_options = ['Terpenuhi', 'Cukup Terpenuhi', 'Sedikit Terpenuhi']
                                asuhan_options = ['Baik', 'Sedang', 'Buruk']
                                sanitasi_options = ['Baik', 'Sedang', 'Buruk']

                                new_data_input['jenis kelamin'] = st.selectbox("Select Jenis Kelamin", gender_options)
                                new_data_input['gizi ibu'] = st.selectbox("Select Gizi Ibu", gizi_options)
                                new_data_input['pola asuhan'] = st.selectbox("Select Pola Asuhan", asuhan_options)
                                new_data_input['sanitasi'] = st.selectbox("Select Sanitasi", sanitasi_options)

                                # Predict button
                                if st.button("Predict Cluster"):
                                    # Create a DataFrame from the new data input
                                    new_data_df = pd.DataFrame([new_data_input])

                                    # Predict the cluster
                                    predicted_clusters = predict_new_data(new_data_df, scaler, pca, kmeans)

                                    if predicted_clusters is not None:
                                        st.subheader("Predicted Cluster")
                                        st.write(f"The predicted cluster for the new data point is: Cluster {predicted_clusters[0]}") # Access the first element if only one prediction
                                    else:
                                        st.error("Prediction failed. Please check your input and uploaded data.")

                            elif prediction_method == 'Load from Database':
                                st.markdown("Enter database connection details to load data for prediction.")

                                db_host = st.text_input("Database Host", value="localhost")
                                db_name = st.text_input("Database Name")
                                db_user = st.text_input("Database User")
                                db_password = st.text_input("Database Password", type="password")
                                db_table = st.text_input("Database Table Name (Optional)")
                                db_query = st.text_area("SQL Query (Optional - overrides Table Name)")


                                if st.button("Load Data from Database"):
                                    connection = create_db_connection(db_host, db_name, db_user, db_password)

                                    if connection:
                                        try:
                                            if db_query:
                                                # Execute user-provided query
                                                new_data_df = pd.read_sql(db_query, connection)
                                                st.success("Data loaded successfully from database using custom query!")
                                            elif db_table:
                                                # Execute query to get all data from the specified table
                                                new_data_df = pd.read_sql(f"SELECT * FROM {db_table}", connection)
                                                st.success(f"Data loaded successfully from table '{db_table}'!")
                                            else:
                                                st.warning("Please provide either a Table Name or a SQL Query.")
                                                new_data_df = None # Ensure new_data_df is None if no input

                                            if new_data_df is not None and not new_data_df.empty:
                                                st.write("Loaded Data Preview:")
                                                st.dataframe(new_data_df.head())

                                                # Predict clusters for the loaded data
                                                predicted_clusters = predict_new_data(new_data_df, scaler, pca, kmeans)

                                                if predicted_clusters is not None:
                                                    # Add predicted clusters to the loaded DataFrame for display
                                                    new_data_df['Predicted_Cluster'] = predicted_clusters

                                                    # Display predicted clusters
                                                    st.subheader("Predicted Clusters for Data from Database")
                                                    st.dataframe(new_data_df)

                                                    # Download the predicted data
                                                    csv_predicted_data = new_data_df.to_csv(index=False).encode('utf-8')
                                                    st.download_button(
                                                        label="Download Predicted Data as CSV",
                                                        data=csv_predicted_data,
                                                        file_name="predicted_data.csv",
                                                        mime="text/csv"
                                                    )

                                                else:
                                                    st.error("Prediction failed for the loaded data. Please check the data format.")


                                            elif new_data_df is not None and new_data_df.empty:
                                                 st.warning("The query returned an empty dataset.")


                                        except Error as e:
                                            st.error(f"Error executing query: '{e}'")
                                        except Exception as e:
                                             st.error(f"An unexpected error occurred during data loading or prediction: {e}")
                                        finally:
                                            if connection and connection.is_connected():
                                                connection.close()
                                                st.info("Database connection closed.")
                                    else:
                                         st.error("Could not establish database connection.")


                        else:
                            st.error("KMeans clustering failed.")
                    else:
                         st.warning("Please select at least 2 clusters.")
                else:
                    st.error("PCA failed.")
            else:
                 st.warning("Please select at least 1 PCA component.")

        else:
            st.error("Preprocessing failed.")

    else:
        st.info("Please upload an Excel file to get started.")

if __name__ == "__main__":
    main()