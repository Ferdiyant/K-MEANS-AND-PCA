import streamlit as st
import page1_input
import page2_prediksi

# Sidebar navigasi
st.sidebar.title("Klasterisasi Stunting Bondowoso")
halaman = st.sidebar.radio("Pilih Halaman:", ["Input Data", "Prediksi"])

# Routing ke halaman sesuai pilihan
if halaman == "Input Data":
    input.run()
elif page == "Prediksi":
    prediksi.run()



