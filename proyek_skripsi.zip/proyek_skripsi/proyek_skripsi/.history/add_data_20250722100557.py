import streamlit as st
from sqlalchemy import create_engine
import pandas as pd

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def add_data():
    st.subheader("➕ Tambah Data Anak")

    with st.form("form_tambah"):
        nama = st.text_input("Nama Anak")
        jk = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"])
        kec = st.text_input("Kecamatan")
        umur = st.number_input("Umur (bulan)", min_value=0)
        tb = st.number_input("Tinggi Badan (cm)", min_value=0.0)
        bb = st.number_input("Berat Badan (kg)", min_value=0.0)
        gizi = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"])
        pend_ayah = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "Sarjana"])
        pend_ibu = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "Sarjana"])
        asupan = st.selectbox("Asupan Makanan", ["Cukup", "Kurang", "Lebih"])

        submit = st.form_submit_button("Simpan Data")

    if submit:
        try:
            with engine.begin() as conn:
                conn.execute(
                    "INSERT INTO stunting (Nama, JK, KEC, U, TB, BB, GI, PA, PE, SA) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                    (nama, jk, kec, umur, tb, bb, gizi, pend_ayah, pend_ibu, asupan)
                )
            st.success("✅ Data berhasil ditambahkan.")
        except Exception as e:
            st.error(f"Gagal menyimpan data: {e}")