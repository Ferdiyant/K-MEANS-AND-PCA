import streamlit as st
import page1_input
import page2_prediksi

# Sidebar navigasi
st.sidebar.title("Klasterisasi Stunting Bondowoso")
page = st.sidebar.radio("Pilih Halaman:", ["Input Data", "Prediksi"])

# Routing ke halaman sesuai pilihan
if page == "Input Data":
    page1_input.run()
elif page == "Prediksi":
    page2_prediksi.run()


from sqlalchemy import create_engine
import pandas as pd
import streamlit as st

# Ganti sesuai konfigurasi MySQL kamu
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

# Query
query = "SELECT * FROM stunting"
df = pd.read_sql(query, engine)

st.dataframe(df)
