import streamlit as st
import input
#import prediksi
from read_data import show_data
from add_data import add_data
from update_data import update_data
from delete_data import delete_data

st.set_page_config(page_title="Aplikasi Data Stunting", layout="wide")

# Navigasi dengan session_state
if "menu" not in st.session_state:
    st.session_state.menu = "📋 Lihat Data"

menu = st.sidebar.radio("Navigasi", ["📋 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑 Hapus"], 
                        index=["📋 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑 Hapus"].index(st.session_state.menu))

if menu == "📋 Lihat Data":
    show_data()
elif menu == "➕ Tambah":
    add_data()
elif menu == "✏️ Edit":
    update_data()
elif menu == "🗑 Hapus":
    delete_data()


# Sidebar navigasi
#st.sidebar.title("Klasterisasi Stunting Bondowoso")
#halaman = st.sidebar.radio("Pilih Halaman:", ["Input Data", "Prediksi"])

# Routing ke halaman sesuai pilihan
#if halaman == "Input Data":
    #input.run()
elif halaman == "Prediksi":
    prediksi.run()



