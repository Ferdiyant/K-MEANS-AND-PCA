import streamlit as st
from sqlalchemy import create_engine
import pandas as pd

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def delete_data():
    st.subheader("🗑 Hapus Data Anak")

    df = pd.read_sql("SELECT * FROM stunting", engine)

    selected_nama = st.selectbox("Pilih Nama yang Akan Dihapus", df["Nama"].unique())

    if st.button("Hapus"):
        try:
            with engine.begin() as conn:
                conn.execute("DELETE FROM stunting WHERE Nama=%s", (selected_nama,))
            st.success(f"✅ Data '{selected_nama}' berhasil dihapus.")
        except Exception as e:
            st.error(f"Gagal menghapus data: {e}")