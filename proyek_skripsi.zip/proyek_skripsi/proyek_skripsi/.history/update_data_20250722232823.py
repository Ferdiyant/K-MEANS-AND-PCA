import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("🔄 Update Data Stunting")

    # Ambil data dari tabel 'stunting'
    df = pd.read_sql("SELECT * FROM stunting", con=engine)
    st.dataframe(df)

    # Input untuk memilih ID data yang akan diupdate
    selected_id = st.number_input("Pilih ID Data untuk Diperbarui", min_value=1, step=1)

    # Ambil baris data yang sesuai dengan ID
    selected_row = df[df["id"] == selected_id].squeeze() if selected_id in df["id"].values else None

    if selected_row is not None:
        with st.form("form_update"):
            # Ambil nilai-nilai default dari row
            nama = st.text_input("Nama", value=selected_row.get("Nama", ""))
            umur = st.number_input("Umur", min_value=0, value=int(selected_row.get("Umur", 0)))
            pe = st.number_input("Pendapatan Ekonomi", min_value=0, value=int(selected_row.get("Pendapatan Ekonomi", 0)))

            # Jenis Kelamin
            jk_options = ["Laki-laki", "Perempuan"]
            jk_value = selected_row.get("JK", "Laki-laki")
            if jk_value not in jk_options:
                jk_value = "Laki-laki"
            jk = st.selectbox("Jenis Kelamin", jk_options, index=jk_options.index(jk_value))

            # Pola Asuhan
            pola_asuhan_options = ["Baik", "Sedang", "Buruk"]
            pa_value = selected_row.get("PA", "Baik")
            if pa_value not in pola_asuhan_options:
                pa_value = "Baik"
            pa = st.selectbox("Pola Asuhan", pola_asuhan_options, index=pola_asuhan_options.index(pa_value))

            # Status Gizi
            gizi_options = ["Baik", "Sedang", "Buruk"]
            gi_value = selected_row.get("GI", "Baik")
            if gi_value not in gizi_options:
                gi_value = "Baik"
            gi = st.selectbox("Status Gizi", gizi_options, index=gizi_options.index(gi_value))

            submitted = st.form_submit_button("Update Data")

            if submitted:
                try:
                    query = """
                        UPDATE stunting 
                        SET Nama = %s, Umur = %s, `Pendapatan Ekonomi` = %s, JK = %s, PA = %s, GI = %s 
                        WHERE id = %s
                    """
                    values = (nama, umur, pe, jk, pa, gi, selected_id)
                    with engine.begin() as conn:
                        conn.execute(query, values)
                    st.success("✅ Data berhasil diperbarui!")
                except Exception as e:
                    st.error(f"❌ Gagal memperbarui data: {e}")
    else:
        st.warning("⚠️ ID tidak ditemukan di database.")
