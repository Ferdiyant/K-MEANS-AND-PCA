import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import pymysql

# Koneksi ke database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.subheader("✏️ Edit Data Stunting")

    # Ambil data dari database
    df = pd.read_sql("SELECT * FROM stunting", engine)

    # Tampilkan data dalam tabel
    selected_index = st.selectbox("Pilih ID untuk diedit", df.index, format_func=lambda x: f"ID {df['id'][x]} - {df['Nama'][x]}")

    selected_row = df.loc[selected_index]

    # Definisikan pilihan tetap
    jk_options = ["L", "P"]
    gizi_options = ["Baik", "Buruk", "Kurang", "Lebih"]
    pend_options = ["SD", "SMP", "SMA", "Sarjana"]
    asupan_options = ["Cukup", "Kurang", "Lebih"]

    # Ambil nilai awal yang aman untuk setiap selectbox
    jk_index = jk_options.index(selected_row["JK"]) if selected_row["JK"] in jk_options else 0
    gizi_index = gizi_options.index(selected_row["GI"]) if selected_row["GI"] in gizi_options else 0
    pend_ayah_index = pend_options.index(selected_row["PA"]) if selected_row["PA"] in pend_options else 0
    pend_ibu_index = pend_options.index(selected_row["PE"]) if selected_row["PE"] in pend_options else 0
    asupan_index = asupan_options.index(selected_row["SA"]) if selected_row["SA"] in asupan_options else 0

    # Form Edit
    with st.form("form_update"):
        nama = st.text_input("Nama", selected_row["Nama"])
        umur = st.number_input("Umur", min_value=0, value=int(selected_row["Umur"]))
        JK = st.selectbox("Jenis Kelamin", jk_options, index=jk_index)
        GI = st.selectbox("Status Gizi", gizi_options, index=gizi_index)
        PA = st.selectbox("Pendidikan Ayah", pend_options, index=pend_ayah_index)
        PE = st.selectbox("Pendidikan Ibu", pend_options, index=pend_ibu_index)
        SA = st.selectbox("Asupan Makanan", asupan_options, index=asupan_index)

        submitted = st.form_submit_button("💾 Simpan Perubahan")

        if submitted:
            try:
                # Update data
                conn = engine.raw_connection()
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE stunting SET Nama=%s, Umur=%s, JK=%s, GI=%s, PA=%s, PE=%s, SA=%s WHERE id=%s
                """, (nama, umur, JK, GI, PA, PE, SA, selected_row["id"]))
                conn.commit()
                cursor.close()
                conn.close()

                st.success("✅ Data berhasil diperbarui.")
                st.rerun()

            except Exception as e:
                st.error(f"❌ Gagal memperbarui data: {e}")