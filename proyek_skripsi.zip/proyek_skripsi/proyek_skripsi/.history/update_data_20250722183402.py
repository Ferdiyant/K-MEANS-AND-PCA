import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
import pymysql

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.subheader("✏️ Update Data Stunting")

    # Ambil data dari database
    try:
        df = pd.read_sql("SELECT * FROM stunting", con=engine)
    except Exception as e:
        st.error(f"Gagal mengambil data: {e}")
        return

    # Pilih data berdasarkan Nama
    nama_list = df["Nama"].tolist()
    selected_nama = st.selectbox("Pilih Nama untuk diupdate:", nama_list)

    # Filter baris yang dipilih
    selected_row = df[df["Nama"] == selected_nama].iloc[0]

    with st.form("form_update"):
        nama = st.text_input("Nama", value=selected_row.get("Nama", ""))
        umur = st.number_input("Umur", min_value=0, value=int(selected_row.get("Umur", 0)))

        # Jenis Kelamin
        jk_list = ["L", "P"]
        jk_value = selected_row.get("JK", "L")
        JK = st.selectbox("Jenis Kelamin", jk_list, index=jk_list.index(jk_value) if jk_value in jk_list else 0)

        # Status Gizi
        gi_list = ["Baik", "Buruk", "Kurang", "Lebih"]
        gi_value = selected_row.get("GI", "Baik")
        GI = st.selectbox("Status Gizi", gi_list, index=gi_list.index(gi_value) if gi_value in gi_list else 0)

        # Pendidikan Ayah
        pa_list = ["SD", "SMP", "SMA", "Sarjana"]
        pa_value = selected_row.get("PA", "SD")
        PA = st.selectbox("Pendidikan Ayah", pa_list, index=pa_list.index(pa_value) if pa_value in pa_list else 0)

        # Pendidikan Ibu
        pe_list = ["SD", "SMP", "SMA", "Sarjana"]
        pe_value = selected_row.get("PE", "SD")
        PE = st.selectbox("Pendidikan Ibu", pe_list, index=pe_list.index(pe_value) if pe_value in pe_list else 0)

        # Asupan Makanan
        sa_list = ["Cukup", "Kurang", "Lebih"]
        sa_value = selected_row.get("SA", "Cukup")
        SA = st.selectbox("Asupan Makanan", sa_list, index=sa_list.index(sa_value) if sa_value in sa_list else 0)

        submit = st.form_submit_button("🔄 Update")

        if submit:
            try:
                conn = engine.raw_connection()
                cursor = conn.cursor()

                cursor.execute("""
                    UPDATE stunting 
                    SET Nama=%s, Umur=%s, JK=%s, GI=%s, PA=%s, PE=%s, SA=%s 
                    WHERE Nama=%s
                """, (nama, umur, JK, GI, PA, PE, SA, selected_nama))

                conn.commit()
                cursor.close()
                conn.close()

                st.success("✅ Data berhasil diperbarui.")
                st.rerun()

            except Exception as e:
                st.error(f"❌ Gagal memperbarui data: {e}")
