#from sqlalchemy import create_engine
#import pandas as pd
import streamlit as st

# Ganti sesuai konfigurasi MySQL kamu
#engine = create_engine("mysql+pymysql://root:@localhost/mydb")

conn = st. connection('mysql', type='sql')
df = conn.query('SELECT * from stunting;' ttl=600)

for row in df.itertuples():
    st.write(f"{row[0]} has a:{row[9]}:")

# Query
#query = "SELECT * FROM stunting"
#df = pd.read_sql(query, engine)

#st.dataframe(df)
