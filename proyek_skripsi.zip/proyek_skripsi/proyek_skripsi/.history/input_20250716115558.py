import streamlit as st
from sqlalchemy import create_engine, text
import pandas as pd

# Koneksi ke database MySQL
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def run():
    st.title("📥 Input & Manajemen Data Stunting")

    # --- FILTER PENCARIAN ---
    st.subheader("📋 Data Saat Ini")
    with st.expander("🔎 Filter Data"):
        search_nama = st.text_input("Cari berdasarkan Nama")
        filter_jk = st.selectbox("Filter Jenis Kelamin", ["Semua", "Laki-laki", "Perempuan"])
        filter_kec = st.selectbox("Filter Kecamatan", ["Semua"] + list(pd.read_sql("SELECT DISTINCT KEC FROM stunting", engine)["KEC"]))

    df = pd.read_sql("SELECT * FROM stunting", engine)

    if search_nama:
        df = df[df["Nama"].str.contains(search_nama, case=False)]

    if filter_jk != "Semua":
        df = df[df["JK"] == filter_jk]

    if filter_kec != "Semua":
        df = df[df["KEC"] == filter_kec]

    if df.empty:
        st.info("Data tidak ditemukan.")
    else:
        st.subheader("📊 Tabel Data Interaktif")

        for index, row in df.iterrows():
            with st.expander(f"ID {row['id']} - {row['Nama']}"):
                with st.form(f"edit_form_{row['id']}"):
                    Nama = st.text_input("Nama", value=row["Nama"])
                    JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"], index=0 if row["JK"] == "Laki-laki" else 1)
                    KEC = st.text_input("Kecamatan", value=row["KEC"])
                    U = st.number_input("Umur", min_value=0, max_value=60, value=row["U"])
                    TB = st.number_input("Tinggi Badan", min_value=0.0, value=row["TB"])
                    BB = st.number_input("Berat Badan", min_value=0.0, value=row["BB"])
                    GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], index=["Baik", "Buruk", "Kurang", "Lebih"].index(row["GI"]))
                    PA = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "S1", "Lainnya"], index=["SD", "SMP", "SMA", "S1", "Lainnya"].index(row["PA"]))
                    PE = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "S1", "Lainnya"], index=["SD", "SMP", "SMA", "S1", "Lainnya"].index(row["PE"]))
                    SA = st.selectbox("Asupan Makanan", ["Cukup", "Kurang", "Lebih"], index=["Cukup", "Kurang", "Lebih"].index(row["SA"]))

                    col1, col2 = st.columns(2)
                    with col1:
                        update = st.form_submit_button("💾 Simpan Perubahan")
                    with col2:
                        hapus = st.form_submit_button("🗑 Hapus Data")

                    if update:
                        try:
                            with engine.begin() as conn:
                                conn.execute(text("""
                                    UPDATE stunting SET
                                        Nama=:Nama, JK=:JK, KEC=:KEC, U=:U, TB=:TB,
                                        BB=:BB, GI=:GI, PA=:PA, PE=:PE, SA=:SA
                                    WHERE id=:id
                                """), {
                                    "Nama": Nama, "JK": JK, "KEC": KEC, "U": U, "TB": TB,
                                    "BB": BB, "GI": GI, "PA": PA, "PE": PE, "SA": SA,
                                    "id": row["id"]
                                })
                            st.success(f"✅ Data ID {row['id']} diperbarui.")
                            st.experimental_rerun()
                        except Exception as e:
                            st.error(f"❌ Gagal update: {e}")

                    if hapus:
                        try:
                            with engine.begin() as conn:
                                conn.execute(text("DELETE FROM stunting WHERE id=:id"), {"id": row["id"]})
                            st.success(f"✅ Data ID {row['id']} dihapus.")
                            st.experimental_rerun()
                        except Exception as e:
                            st.error(f"❌ Gagal hapus: {e}")

    # --- TAMBAH DATA BARU ---
    st.subheader("➕ Tambah Data Baru")
    with st.form("tambah_form"):
        Nama = st.text_input("Nama Anak", key="Nama")
        JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"], key="JK")
        KEC = st.text_input("Kecamatan", key="KEC")
        U = st.number_input("Umur (bulan)", min_value=0, max_value=60, key="U")
        TB = st.number_input("Tinggi Badan (cm)", min_value=0.0, key="TB")
        BB = st.number_input("Berat Badan (kg)", min_value=0.0, key="BB")
        GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"], key="GI")
        PA = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "S1", "Lainnya"], key="PA")
        PE = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "S1", "Lainnya"], key="PE")
        SA = st.selectbox("Status Asupan Makanan", ["Cukup", "Kurang", "Lebih"], key="SA")
        simpan = st.form_submit_button("📤 Simpan ke Database")

    if simpan:
        if not Nama.strip():
            st.error("❌ Nama tidak boleh kosong.")
        elif U == 0 or TB == 0.0 or BB == 0.0:
            st.error("❌ Umur, TB, dan BB tidak boleh 0.")
        else:
            try:
                with engine.begin() as conn:
                    conn.execute(text("""
                        INSERT INTO stunting (Nama, JK, KEC, U, TB, BB, GI, PA, PE, SA)
                        VALUES (:Nama, :JK, :KEC, :U, :TB, :BB, :GI, :PA, :PE, :SA)
                    """), {
                        "Nama": Nama, "JK": JK, "KEC": KEC, "U": U, "TB": TB,
                        "BB": BB, "GI": GI, "PA": PA, "PE": PE, "SA": SA
                    })
                st.success("✅ Data berhasil ditambahkan!")
                for key in ["Nama", "JK", "KEC", "U", "TB", "BB", "GI", "PA", "PE", "SA"]:
                    st.session_state[key] = "" if key in ["Nama", "KEC"] else 0
                st.experimental_rerun()
            except Exception as e:
                st.error(f"❌ Gagal menyimpan data: {e}")
