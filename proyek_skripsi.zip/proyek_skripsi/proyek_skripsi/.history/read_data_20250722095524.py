import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def show_data():
    st.subheader("📋 Data Anak Stunting")

    df = pd.read_sql("SELECT * FROM stunting", engine)
    st.dataframe(df, use_container_width=True)

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("➕ Input Data Baru"):
            st.session_state.menu = "➕ Tambah"
            st.rerun()
    with col2:
        if st.button("🔄 Update Data"):
            st.session_state.menu = "✏️ Edit"
            st.rerun()
    with col3:
        if st.button("🗑 Hapus Data"):
            st.session_state.menu = "🗑 Hapus"
            st.rerun()
