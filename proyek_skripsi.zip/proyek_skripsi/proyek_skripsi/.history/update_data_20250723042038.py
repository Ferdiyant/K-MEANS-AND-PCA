import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("🔄 Update Data Stunting")

    # Ambil data dari tabel 'stunting'
    df = pd.read_sql("SELECT * FROM stunting", con=engine)

    # Tampilkan data yang ada
    st.subheader("📋 Data Saat Ini")
    st.dataframe(df)

    # Input untuk memilih ID data yang akan diubah
    selected_id = st.number_input("Masukkan ID Data yang Ingin Diperbarui", min_value=1, step=1)

    # Ambil data berdasarkan ID
    selected_row = df[df["id"] == selected_id].squeeze() if selected_id in df["id"].values else None

    if selected_row is not None:
        st.subheader(f"✏️ Perbarui Data untuk ID: {selected_id}")
        with st.form("form_update"):
            nama = st.text_input("Nama", value=selected_row["Nama"])
            umur = st.number_input("Umur", min_value=0, value=int(selected_row["Umur"]))
            pendapatan = st.number_input("Pendapatan Ekonomi", min_value=0, value=int(selected_row["Pendapatan Ekonomi"]))

            # Jenis Kelamin
            jk_options = ["Laki-laki", "Perempuan"]
            jk_value = selected_row["JK"]
            if jk_value not in jk_options:
                jk_value = "Laki-laki"
            jk = st.selectbox("Jenis Kelamin", jk_options, index=jk_options.index(jk_value))

            # Pola Asuhan
            pa_options = ["Baik", "Sedang", "Buruk"]
            pa_value = selected_row.get("PA", "Baik")
            if pa_value not in pa_options:
                pa_value = "Baik"
            pa = st.selectbox("Pola Asuhan", pa_options, index=pa_options.index(pa_value))

            # Status Gizi
            gi_options = ["Baik", "Sedang", "Buruk"]
            gi_value = selected_row.get("GI", "Baik")
            if gi_value not in gi_options:
                gi_value = "Baik"
            gi = st.selectbox("Status Gizi", gi_options, index=gi_options.index(gi_value))

            # Tombol Submit
            submitted = st.form_submit_button("💾 Simpan Perubahan")

            if submitted:
                try:
                    update_query = """
                        UPDATE stunting
                        SET Nama = %s, Umur = %s, `Pendapatan Ekonomi` = %s, JK = %s, PA = %s, GI = %s
                        WHERE id = %s
                    """
                    values = (nama, umur, pendapatan, jk, pa, gi, selected_id)

                    with engine.begin() as conn:
                        conn.execute(update_query, values)

                    st.success("✅ Data berhasil diperbarui!")
                except Exception as e:
                    st.error(f"❌ Gagal memperbarui data: {e}")
    else:
        st.warning("⚠️ ID tidak ditemukan. Harap masukkan ID yang valid.")
