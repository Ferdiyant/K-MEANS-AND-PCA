import streamlit as st
from sqlalchemy import create_engine, text
import pandas as pd

# Koneksi ke database MySQL
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def run():
    st.title("📥 Input & Manajemen Data Stunting")

    # --- FILTER PENCARIAN ---
    st.subheader("📋 Data Saat Ini")
    with st.expander("🔎 Filter Data"):
        search_nama = st.text_input("Cari berdasarkan Nama")
        filter_jk = st.selectbox("Filter Jenis Kelamin", ["Semua", "Laki-laki", "Perempuan"])
        filter_kec = st.selectbox("Filter Kecamatan", ["Semua"] + list(pd.read_sql("SELECT DISTINCT KEC FROM stunting", engine)["KEC"]))

    df = pd.read_sql("SELECT * FROM stunting", engine)

    if search_nama:
        df = df[df["Nama"].str.contains(search_nama, case=False)]

    if filter_jk != "Semua":
        df = df[df["JK"] == filter_jk]

    if filter_kec != "Semua":
        df = df[df["KEC"] == filter_kec]

    if df.empty:
        st.info("Data tidak ditemukan.")
    else:
        st.dataframe(df)

        st.subheader("✏️ Edit / 🗑 Hapus Data")
        selected_id = st.selectbox("Pilih ID", df["id"])
        selected_row = df[df["id"] == selected_id].iloc[0]

        with st.expander("✏️ Form Edit Data"):
            with st.form("edit_form"):
                Nama = st.text_input("Nama", value=selected_row["Nama"])
                JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"], index=0 if selected_row["JK"] == "Laki-laki" else 1)
                KEC = st.text_input("Kecamatan", value=selected_row["KEC"])
                U = st.number_input("Umur", min_value=0, max_value=60, value=selected_row["U"])
                TB = st.number_input("Tinggi Badan", min_value=0.0, value=selected_row["TB"])
                BB = st.number_input("Berat Badan", min_value=0.0, value=selected_row["BB"])

                # Daftar pilihan
                GI_options = ["Baik", "Buruk", "Kurang", "Lebih"]
                PA_options = ["SD", "SMP", "SMA", "S1", "Lainnya"]
                PE_options = ["SD", "SMP", "SMA", "S1", "Lainnya"]
                SA_options = ["Cukup", "Kurang", "Lebih"]

                # Validasi isi data
                GI_val = selected_row["GI"] if selected_row["GI"] in GI_options else "Baik"
                PA_val = selected_row["PA"] if selected_row["PA"] in PA_options else "SD"
                PE_val = selected_row["PE"] if selected_row["PE"] in PE_options else "SD"
                SA_val = selected_row["SA"] if selected_row["SA"] in SA_options else "Cukup"

                # Selectbox aman
                GI = st.selectbox("Status Gizi", GI_options, index=GI_options.index(GI_val))
                PA = st.selectbox("Pendidikan Ayah", PA_options, index=PA_options.index(PA_val))
                PE = st.selectbox("Pendidikan Ibu", PE_options, index=PE_options.index(PE_val))
                SA = st.selectbox("Asupan Makanan", SA_options, index=SA_options.index(SA_val))

                update = st.form_submit_button("💾 Simpan Perubahan")
                if update:
                    try:
                        with engine.begin() as conn:
                            conn.execute(text("""
                                UPDATE stunting SET
                                    Nama=:Nama, JK=:JK, KEC=:KEC, U=:U, TB=:TB,
                                    BB=:BB, GI=:GI, PA=:PA, PE=:PE, SA=:SA
                                WHERE id=:id
                            """), {
                                "Nama": Nama, "JK": JK, "KEC": KEC, "U": U, "TB": TB,
                                "BB": BB, "GI": GI, "PA": PA, "PE": PE, "SA": SA,
                                "id": selected_id
                            })
                        st.success("✅ Data berhasil diperbarui.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Gagal update: {e}")

        if st.button("🗑 Hapus Data ID Ini"):
            try:
                with engine.begin() as conn:
                    conn.execute(text("DELETE FROM stunting WHERE id=:id"), {"id": selected_id})
                st.success(f"✅ Data dengan ID {selected_id} berhasil dihapus.")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Gagal hapus: {e}")

    # --- TAMBAH DATA BARU ---
    st.subheader("➕ Tambah Data Baru")
    with st.form("tambah_form"):
        Nama = st.text_input("Nama Anak")
        JK = st.selectbox("Jenis Kelamin", ["Laki-laki", "Perempuan"])
        KEC = st.text_input("Kecamatan")
        U = st.number_input("Umur (bulan)", min_value=0, max_value=60)
        TB = st.number_input("Tinggi Badan (cm)", min_value=0.0)
        BB = st.number_input("Berat Badan (kg)", min_value=0.0)
        GI = st.selectbox("Status Gizi", ["Baik", "Buruk", "Kurang", "Lebih"])
        PA = st.selectbox("Pendidikan Ayah", ["SD", "SMP", "SMA", "S1", "Lainnya"])
        PE = st.selectbox("Pendidikan Ibu", ["SD", "SMP", "SMA", "S1", "Lainnya"])
        SA = st.selectbox("Status Asupan Makanan", ["Cukup", "Kurang", "Lebih"])
        simpan = st.form_submit_button("📤 Simpan ke Database")

    if simpan:
        if not Nama.strip():
            st.error("❌ Nama tidak boleh kosong.")
        elif U == 0 or TB == 0.0 or BB == 0.0:
            st.error("❌ Umur, TB, dan BB tidak boleh 0.")
        else:
            try:
                with engine.begin() as conn:
                    conn.execute(text("""
                        INSERT INTO stunting (Nama, JK, KEC, U, TB, BB, GI, PA, PE, SA)
                        VALUES (:Nama, :JK, :KEC, :U, :TB, :BB, :GI, :PA, :PE, :SA)
                    """), {
                        "Nama": Nama, "JK": JK, "KEC": KEC, "U": U, "TB": TB,
                        "BB": BB, "GI": GI, "PA": PA, "PE": PE, "SA": SA
                    })
                st.success("✅ Data berhasil ditambahkan!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Gagal menyimpan data: {e}")
