import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("🔄 Update Data Stunting")

    # Ambil data dari database
    df = pd.read_sql("SELECT * FROM data_stunting", con=engine)

    # Tampilkan data dalam tabel
    st.dataframe(df)

    # Pilih baris yang akan diupdate
    selected_index = st.number_input("Pilih ID Data untuk Diperbarui (ID)", min_value=1, step=1)

    # Filter baris berdasarkan ID
    selected_row = df[df["id"] == selected_index].squeeze() if selected_index in df["id"].values else None

    if selected_row is not None:
        with st.form("form_update"):
            nama = st.text_input("Nama", value=selected_row.get("Nama", ""))
            umur = st.number_input("Umur", min_value=0, value=int(selected_row.get("Umur", 0)))

            # Jenis Kelamin
            jk_options = ["Laki-laki", "Perempuan"]
            jk_value = selected_row.get("JK", "Laki-laki")
            if jk_value not in jk_options:
                jk_value = "Laki-laki"
            JK = st.selectbox("Jenis Kelamin", jk_options, index=jk_options.index(jk_value))

            # Pendidikan Ibu
            pend_ibu_options = ["SD", "SMP", "SMA", "Sarjana"]
            pe_value = selected_row.get("PE", "SD")
            if isinstance(pe_value, (int, float)):
                pe_value = pend_ibu_options[int(pe_value) - 1] if 1 <= int(pe_value) <= len(pend_ibu_options) else "SD"
            if pe_value not in pend_ibu_options:
                pe_value = "SD"
            PE = st.selectbox("Pendidikan Ibu", pend_ibu_options, index=pend_ibu_options.index(pe_value))

            # Status Gizi
            gizi_options = ["Baik", "Buruk", "Kurang", "Lebih"]
            gi_value = selected_row.get("GI", "Baik")
            if gi_value not in gizi_options:
                gi_value = "Baik"
            GI = st.selectbox("Status Gizi", gizi_options, index=gizi_options.index(gi_value))

            submitted = st.form_submit_button("Update Data")

            if submitted:
                try:
                    query = f"""
                        UPDATE data_stunting 
                        SET Nama = %s, Umur = %s, JK = %s, PE = %s, GI = %s 
                        WHERE id = %s
                    """
                    values = (nama, umur, JK, PE, GI, selected_index)
                    with engine.begin() as conn:
                        conn.execute(query, values)
                    st.success("✅ Data berhasil diperbarui!")
                except Exception as e:
                    st.error(f"❌ Gagal memperbarui data: {e}")
    else:
        st.warning("⚠️ ID tidak ditemukan di database.")
