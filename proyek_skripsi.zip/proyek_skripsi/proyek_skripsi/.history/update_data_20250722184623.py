import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

# Setup koneksi database
engine = create_engine("mysql+pymysql://root:@localhost/mydb")

def update_data():
    st.title("Update Data Stunting")

    try:
        df = pd.read_sql("SELECT * FROM stunting", engine)
    except Exception as e:
        st.error(f"Gagal mengambil data: {e}")
        return

    if df.empty:
        st.warning("Tidak ada data untuk diperbarui.")
        return

    # Pilih baris berdasarkan ID
    selected_id = st.selectbox("Pilih ID yang ingin diperbarui", df["id"])
    selected_row = df[df["id"] == selected_id].iloc[0]

    with st.form("form_update"):
        nama = st.text_input("Nama", selected_row["Nama"])
        umur = st.number_input("Umur", min_value=0, value=int(selected_row["Umur"]))

        jk_list = ["Laki-laki", "Perempuan"]
        jk_value = selected_row.get("JK", "Laki-laki")
        if jk_value not in jk_list:
            jk_value = "Laki-laki"
        JK = st.selectbox("Jenis Kelamin", jk_list, index=jk_list.index(jk_value))

        pend_ibu_list = ["SD", "SMP", "SMA", "Sarjana"]
        pend_ibu_value = selected_row.get("PE", "SD")
        if pend_ibu_value not in pend_ibu_list:
            pend_ibu_value = "SD"
        PE = st.selectbox("Pendidikan Ibu", pend_ibu_list, index=pend_ibu_list.index(pend_ibu_value))

        asupan_list = ["Cukup", "Kurang", "Lebih"]
        asupan_value = selected_row.get("SA", "Cukup")
        if asupan_value not in asupan_list:
            asupan_value = "Cukup"
        SA = st.selectbox("Asupan Makanan", asupan_list, index=asupan_list.index(asupan_value))

        gizi_list = ["Baik", "Buruk", "Kurang", "Lebih"]
        gizi_value = selected_row.get("GI", "Baik")
        if gizi_value not in gizi_list:
            gizi_value = "Baik"
        GI = st.selectbox("Status Gizi", gizi_list, index=gizi_list.index(gizi_value))

        submitted = st.form_submit_button("Update Data")

        if submitted:
            try:
                with engine.begin() as conn:
                    query = """
                        UPDATE data_stunting
                        SET Nama=%s, Umur=%s, JK=%s, PE=%s, SA=%s, GI=%s
                        WHERE id=%s
                    """
                    conn.execute(query, (nama, umur, JK, PE, SA, GI, selected_id))
                st.success("✅ Data berhasil diperbarui.")
                st.experimental_rerun()
            except Exception as e:
                st.error(f"❌ Gagal memperbarui data: {e}")
