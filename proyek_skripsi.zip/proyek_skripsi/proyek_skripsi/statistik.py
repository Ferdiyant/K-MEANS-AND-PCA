import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score
from sqlalchemy import create_engine, text
from mpl_toolkits.mplot3d import Axes3D  # Untuk 3D Plot

def main():
    st.title("PCA and KMeans Clustering Application")

    # Koneksi ke database
    engine = create_engine("mysql+mysqlconnector://root:@localhost/mydb")
    df = pd.read_sql("SELECT * FROM stunting", engine)

    st.subheader("Data Saat Ini")
    st.dataframe(df, use_container_width=True)

    # Preprocessing
    df_processed = df.copy()
    df_processed = df_processed.drop(['KEC', 'Nama'], axis=1, errors='ignore')

    df_processed['jenis kelamin'] = df_processed['JK'].str.lower().map({'laki-laki': 0, 'perempuan': 1})
    df_processed['pola asuhan'] = df_processed['PA'].str.lower().map({'baik': 2, 'sedang': 1, 'buruk': 0})
    df_processed['gizi ibu'] = df_processed['GI'].str.lower().map({'terpenuhi': 2, 'cukup terpenuhi': 1, 'sedikit terpenuhi': 0})
    df_processed['sanitasi'] = df_processed['SA'].str.lower().map({'baik': 2, 'sedang': 1, 'buruk': 0})

    data_numerik = df_processed.select_dtypes(include=[np.number])
    if data_numerik.isnull().values.any():
        st.warning("Data mengandung nilai kosong. Diisi dengan rata-rata kolom.")
        data_numerik = data_numerik.fillna(data_numerik.mean())

    # Sidebar: PCA
    st.sidebar.header("PCA Parameters")
    max_pca_components = min(data_numerik.shape[1], data_numerik.shape[0])
    n_components = st.sidebar.slider("Jumlah Komponen PCA", 1, max_pca_components, min(2, max_pca_components))

    # PCA
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(data_numerik)
    pca = PCA(n_components=n_components)
    x_pca = pca.fit_transform(x_scaled)

    st.header("Hasil PCA")
    st.write(f"Rasio Variansi Terserap: {np.sum(pca.explained_variance_ratio_):.4f}")

    # Grafik explained variance
    explained_variance_ratios = np.cumsum(pca.explained_variance_ratio_)
    fig = plt.figure(figsize=(8, 5))
    plt.plot(range(1, len(explained_variance_ratios) + 1), explained_variance_ratios, marker='o')
    plt.xlabel('Jumlah Komponen')
    plt.ylabel('Kumulatif Variansi Terserap')
    plt.title('Variansi Terserap oleh Komponen PCA')
    plt.grid(True)
    st.pyplot(fig)

    # Sidebar: KMeans
    st.sidebar.header("🔧 KMeans Parameters")
    max_clusters = min(10, x_pca.shape[0] // 2)
    n_clusters = st.sidebar.slider("Jumlah Klaster", 2, max_clusters, min(3, max_clusters))

    # KMeans
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(x_pca)

    df['Cluster'] = clusters  #  Penting untuk ditambahkan sebelum digunakan

    st.header("Hasil Clustering")

    # Visualisasi 2D
    if n_components >= 2:
        fig2d = plt.figure(figsize=(10, 6))
        plt.scatter(x_pca[:, 0], x_pca[:, 1], c=clusters, cmap='viridis', alpha=0.6)
        plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], c='red', s=200, marker='X', label='Centroids')
        plt.title('Visualisasi Klaster (2D: PC1 vs PC2)')
        plt.xlabel('PC1')
        plt.ylabel('PC2')
        plt.legend()
        plt.grid(True)
        st.pyplot(fig2d)

    # Visualisasi 3D
    if n_components >= 3:
        fig3d = plt.figure(figsize=(10, 8))
        ax = fig3d.add_subplot(111, projection='3d')
        ax.scatter(x_pca[:, 0], x_pca[:, 1], x_pca[:, 2], c=clusters, cmap='viridis')
        ax.set_xlabel('PC1')
        ax.set_ylabel('PC2')
        ax.set_zlabel('PC3')
        ax.set_title('Visualisasi Klaster (3D)')
        st.pyplot(fig3d)

    # Evaluasi
    st.write(f"Silhouette Score: {silhouette_score(x_pca, clusters):.4f}")
    st.write(f"Davies-Bouldin Score: {davies_bouldin_score(x_pca, clusters):.4f}")

    # Line chart: Rata-rata fitur numerik per cluster
    st.subheader("Line Chart Rata-rata Semua Fitur Numerik per Cluster")
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    df_numeric = df[numeric_cols].groupby(df['Cluster']).mean().T  # Transpose: fitur di Y-axis

    fig_line, ax = plt.subplots(figsize=(12, 6))
    for cluster in df_numeric.columns:
        ax.plot(df_numeric.index, df_numeric[cluster], marker='o', label=f'Cluster {cluster}')
    ax.set_title("Rata-rata Fitur Numerik per Cluster")
    ax.set_ylabel("Rata-rata")
    ax.set_xlabel("Fitur")
    ax.legend(title="Cluster")
    ax.grid(True)
    plt.xticks(rotation=45)
    st.pyplot(fig_line)

    # Simpan ke database
    try:
        with engine.begin() as conn:
            for idx, row in df.iterrows():
                conn.execute(
                    text("UPDATE stunting SET cluster = :cluster WHERE id = :id"),
                    {"cluster": int(row['Cluster']), "id": int(row['id'])}
                )
        st.success("Cluster berhasil disimpan ke database.")
    except Exception as e:
        st.warning(f"Gagal menyimpan cluster ke database: {e}")

    # Notifikasi anak terbaru masuk ke cluster
    if 'Cluster' in df.columns:
        try:
            cluster_terbaru = int(df.iloc[-1]['Cluster'])
            nama_terbaru = df.iloc[-1]['Nama']
            st.toast(f"Anak terbaru '{nama_terbaru}' masuk ke Cluster {cluster_terbaru}", icon="🧒")
        except:
            st.warning("Tidak dapat menampilkan cluster terbaru.")
    else:
        st.warning("Cluster belum dihitung, tidak bisa menampilkan anak terbaru.")

# Jalankan aplikasi
if __name__ == '__main__':
    main()
